import { SiteHeader } from "@/app/components/site-header"
import { SiteFooter } from "@/app/components/site-footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Target, Eye, Users, BookOpen, FileText, TrendingUp } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-green-700 to-green-900 text-white py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">About CETAPI</h1>
              <p className="text-xl text-green-100 text-pretty">
                Empowering Nigerian entrepreneurs through comprehensive training and evidence-based policy initiatives
              </p>
            </div>
          </div>
        </section>

        {/* Who We Are */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">Who We Are</h2>
              <div className="prose prose-lg max-w-none">
                <p className="text-gray-700 leading-relaxed mb-4">
                  The <strong>Center for Entrepreneurship Training and Policy Initiative (CETAPI)</strong> is a leading
                  Nigerian organization dedicated to fostering entrepreneurial excellence and shaping policies that
                  support sustainable business growth across the nation.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Based in Abuja, Nigeria, CETAPI serves as a bridge between aspiring entrepreneurs, established
                  businesses, and policymakers. We believe that entrepreneurship is the key to Nigeria's economic
                  transformation, and we are committed to providing the tools, knowledge, and advocacy needed to unlock
                  this potential.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Through our comprehensive training programs, research-driven policy initiatives, and collaborative
                  partnerships, we have impacted thousands of entrepreneurs and influenced policies that create an
                  enabling environment for businesses to thrive.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Mission and Vision */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="grid md:grid-cols-2 gap-8">
                <Card className="border-t-4 border-t-green-600 hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <Target className="h-8 w-8 text-green-600" />
                      <CardTitle className="text-2xl">Our Mission</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 leading-relaxed">
                      To equip Nigerian entrepreneurs with world-class training, practical skills, and strategic
                      insights that enable them to build sustainable, innovative, and impactful businesses. We are
                      committed to advocating for policies that create an enabling environment for entrepreneurship to
                      flourish across all sectors of the Nigerian economy.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-t-4 border-t-blue-600 hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <Eye className="h-8 w-8 text-blue-600" />
                      <CardTitle className="text-2xl">Our Vision</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 leading-relaxed">
                      To be Nigeria's most trusted and impactful center for entrepreneurship development, recognized for
                      producing successful entrepreneurs and driving transformative policy changes that position Nigeria
                      as a leading entrepreneurial hub in Africa and beyond.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* What We Do */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">What We Do</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <BookOpen className="h-12 w-12 text-green-600 mb-4" />
                    <CardTitle>Entrepreneurship Training</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We deliver comprehensive training programs covering business planning, financial management,
                      marketing strategies, and operational excellence. Our programs are designed to meet entrepreneurs
                      at every stage of their journey.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <FileText className="h-12 w-12 text-green-600 mb-4" />
                    <CardTitle>Policy Research & Advocacy</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We conduct rigorous research to identify barriers to entrepreneurship and advocate for policies
                      that support business growth, access to finance, regulatory reforms, and innovation ecosystems.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <Users className="h-12 w-12 text-green-600 mb-4" />
                    <CardTitle>Capacity Building</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We organize workshops, seminars, and mentorship programs that connect entrepreneurs with industry
                      experts, successful business leaders, and potential investors.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <TrendingUp className="h-12 w-12 text-green-600 mb-4" />
                    <CardTitle>Business Development Support</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We provide ongoing support to help businesses scale, including access to networks, market
                      opportunities, and strategic guidance for sustainable growth.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <Target className="h-12 w-12 text-green-600 mb-4" />
                    <CardTitle>MSME Empowerment</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We focus specifically on Micro, Small, and Medium Enterprises (MSMEs), providing tailored
                      interventions that address their unique challenges and opportunities.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <Eye className="h-12 w-12 text-green-600 mb-4" />
                    <CardTitle>Strategic Partnerships</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We collaborate with government agencies, development partners, financial institutions, and
                      educational institutions to create a holistic support system for entrepreneurs.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Our Impact */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">Our Impact</h2>
              <div className="prose prose-lg max-w-none">
                <p className="text-gray-700 leading-relaxed mb-4">
                  Since our inception, CETAPI has trained thousands of entrepreneurs across Nigeria, helping them
                  transform their business ideas into thriving enterprises. Our policy advocacy work has contributed to
                  regulatory improvements and increased awareness of entrepreneurship as a driver of economic
                  development.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  We take pride in the success stories of our alumni who have created jobs, contributed to their
                  communities, and become role models for the next generation of Nigerian entrepreneurs. Through our
                  continued efforts, we remain committed to building a vibrant entrepreneurial ecosystem that drives
                  Nigeria's prosperity.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 md:py-24 bg-green-600 text-white">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Join Us in Building Nigeria's Future</h2>
              <p className="text-xl mb-8 text-green-100">
                Whether you're an aspiring entrepreneur, an established business owner, or a partner organization,
                there's a place for you in the CETAPI community.
              </p>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
