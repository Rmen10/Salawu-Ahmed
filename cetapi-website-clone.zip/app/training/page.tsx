import { SiteHeader } from "@/app/components/site-header"
import { SiteFooter } from "@/app/components/site-footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function TrainingPage() {
  const trainings = [
    {
      title: "Business Planning and Strategy Workshop",
      image: "/images/photo-2024-11-11-23-38-17.jpeg",
      description:
        "A comprehensive workshop focused on developing robust business plans and strategic frameworks for sustainable growth. Participants learn to analyze market opportunities, develop competitive strategies, and create actionable business roadmaps.",
    },
    {
      title: "Financial Management for Entrepreneurs",
      image: "/images/photo-2024-11-11-23-35-14.jpeg",
      description:
        "This training equips entrepreneurs with essential financial literacy skills including budgeting, cash flow management, financial forecasting, and understanding financial statements. Participants gain practical tools to make informed financial decisions.",
    },
    {
      title: "MSME Development and Sustainability",
      image: "/images/photo-2024-11-11-23-37-08.jpeg",
      description:
        "Focused on Micro, Small and Medium Enterprises, this program covers operational excellence, scaling strategies, and sustainability practices. Interactive sessions help participants identify growth opportunities and overcome common challenges.",
    },
    {
      title: "Innovation and Business Model Design",
      image: "/images/photo-2024-11-11-23-38-13.jpeg",
      description:
        "An intensive training on developing innovative business models and adapting to changing market dynamics. Entrepreneurs learn design thinking methodologies, customer-centric approaches, and how to pivot their businesses effectively.",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-green-700 to-green-900 text-white py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Our Training Programs</h1>
              <p className="text-xl text-green-100 text-pretty">
                Empowering entrepreneurs through practical, world-class training programs designed for the Nigerian
                business landscape
              </p>
            </div>
          </div>
        </section>

        {/* Training Programs */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto space-y-12">
              {trainings.map((training, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="relative h-64 md:h-full">
                      <Image
                        src={training.image || "/placeholder.svg"}
                        alt={training.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="p-6 flex flex-col justify-center">
                      <CardHeader className="p-0 mb-4">
                        <CardTitle className="text-2xl">{training.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-0">
                        <p className="text-gray-700 leading-relaxed">{training.description}</p>
                      </CardContent>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Business?</h2>
              <p className="text-xl text-gray-700 mb-8">
                Join our upcoming training programs and gain the skills you need to succeed in today's competitive
                business environment.
              </p>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
