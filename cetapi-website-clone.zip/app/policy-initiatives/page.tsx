import { SiteHeader } from "@/app/components/site-header"
import { SiteFooter } from "@/app/components/site-footer"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { FileText, Users, TrendingUp, Briefcase, Scale, Lightbulb } from "lucide-react"

export default function PolicyInitiativesPage() {
  const initiatives = [
    {
      icon: <Scale className="h-8 w-8 text-green-600" />,
      title: "Regulatory Environment Reform",
      description:
        "Advocating for streamlined business registration processes, reduced bureaucratic bottlenecks, and clear regulatory frameworks that enable businesses to operate efficiently and compliantly.",
      impact:
        "Contributed to policy discussions that have led to faster business registration times and clearer guidelines for MSMEs.",
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-green-600" />,
      title: "Access to Finance Initiative",
      description:
        "Working with financial institutions and government agencies to create innovative financing mechanisms, including microfinance options, grants, and loan guarantee schemes for small businesses.",
      impact:
        "Facilitated partnerships that have improved access to capital for hundreds of entrepreneurs across Nigeria.",
    },
    {
      icon: <Users className="h-8 w-8 text-green-600" />,
      title: "MSME Development Policy Framework",
      description:
        "Research and advocacy focused on creating comprehensive policies that support Micro, Small, and Medium Enterprises, including tax incentives, capacity building programs, and market access support.",
      impact:
        "Policy briefs submitted to relevant government ministries have influenced national MSME development strategies.",
    },
    {
      icon: <Briefcase className="h-8 w-8 text-green-600" />,
      title: "Youth Entrepreneurship Empowerment",
      description:
        "Championing policies that prioritize youth entrepreneurship through dedicated funding schemes, mentorship programs, and skills development initiatives tailored to young business owners.",
      impact:
        "Partnerships with youth development agencies have created pathways for thousands of young Nigerians to start businesses.",
    },
    {
      icon: <Lightbulb className="h-8 w-8 text-green-600" />,
      title: "Innovation and Technology Adoption",
      description:
        "Promoting policies that encourage digital transformation, technology adoption, and innovation ecosystems that enable Nigerian businesses to compete globally.",
      impact:
        "Advocacy efforts have contributed to increased government support for tech startups and digital skills training.",
    },
    {
      icon: <FileText className="h-8 w-8 text-green-600" />,
      title: "Trade and Market Access Enhancement",
      description:
        "Working to improve market access for Nigerian entrepreneurs through policy advocacy on trade agreements, export promotion, and local content development.",
      impact: "Research findings have informed national trade policies and export development strategies.",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-green-700 to-green-900 text-white py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Policy Initiatives</h1>
              <p className="text-xl text-green-100 text-pretty">
                Shaping policies that create an enabling environment for entrepreneurship and business growth in Nigeria
              </p>
            </div>
          </div>
        </section>

        {/* Introduction */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                At CETAPI, we believe that sustainable entrepreneurship requires more than just training—it requires an
                enabling policy environment. Our policy initiatives are grounded in rigorous research, stakeholder
                engagement, and evidence-based advocacy.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                We work closely with government agencies, development partners, business associations, and other
                stakeholders to identify policy gaps, propose practical solutions, and advocate for reforms that support
                entrepreneurial success.
              </p>
            </div>
          </div>
        </section>

        {/* Policy Initiatives */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Key Policy Areas</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {initiatives.map((initiative, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="mb-4">{initiative.icon}</div>
                      <CardTitle className="text-xl mb-2">{initiative.title}</CardTitle>
                      <CardDescription className="text-base">{initiative.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-green-50 p-4 rounded-lg border-l-4 border-l-green-600">
                        <p className="text-sm font-semibold text-green-900 mb-1">Impact:</p>
                        <p className="text-sm text-green-800">{initiative.impact}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Approach */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Approach</h2>
              <div className="space-y-6">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Research-Driven</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We conduct thorough research to understand the challenges facing entrepreneurs and identify
                      evidence-based policy solutions that address real-world problems.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Stakeholder Engagement</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We engage with entrepreneurs, policymakers, and other stakeholders to ensure our advocacy reflects
                      diverse perspectives and builds consensus for reform.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Practical Implementation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We don't just propose policies—we work with implementers to ensure recommendations are practical,
                      feasible, and can be effectively executed.
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Monitoring and Evaluation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">
                      We track the implementation of policy reforms and measure their impact, providing ongoing feedback
                      to refine and improve entrepreneurship policies.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 md:py-24 bg-green-600 text-white">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Partner With Us</h2>
              <p className="text-xl text-green-100">
                Join us in shaping policies that create a thriving entrepreneurial ecosystem in Nigeria. Together, we
                can build an environment where businesses flourish and entrepreneurs succeed.
              </p>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
