import { NextResponse } from "next/server"
import Resend from "resend"

export async function POST(request: Request) {
  try {
    const { name, email, message } = await request.json()

    // Basic validation
    if (!name || !email || !message) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    console.log("Feedback received:", {
      name,
      email,
      message,
      to: "Rmen395@gmail.com",
      timestamp: new Date().toISOString(),
    })

    // like Resend, SendGrid, or Nodemailer with proper API keys and configuration
    const resend = new Resend(process.env.RESEND_API_KEY)

    await resend.emails.send({
      from: "CETAPI Website <noreply@your-domain.com>",
      to: "Rmen395@gmail.com",
      subject: `New Feedback from ${name}`,
      html: `
        <h2>New Feedback Submission</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Message:</strong></p>
        <p>${message}</p>
      `,
    })

    return NextResponse.json({ success: true, message: "Feedback sent successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error processing feedback:", error)
    return NextResponse.json({ error: "Failed to send feedback" }, { status: 500 })
  }
}
