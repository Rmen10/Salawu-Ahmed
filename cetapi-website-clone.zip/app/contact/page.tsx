"use client"

import type React from "react"

import { useState } from "react"
import { SiteHeader } from "@/app/components/site-header"
import { SiteFooter } from "@/app/components/site-footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Phone, Mail, MapPin, Building2 } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitStatus("idle")

    try {
      const response = await fetch("/api/send-feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setSubmitStatus("success")
        setFormData({ name: "", email: "", message: "" })
      } else {
        setSubmitStatus("error")
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      setSubmitStatus("error")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-green-700 to-green-900 text-white py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Contact Us</h1>
              <p className="text-xl text-green-100 text-pretty">
                Get in touch with the CETAPI team. We're here to support your entrepreneurship journey.
              </p>
            </div>
          </div>
        </section>

        {/* Team Contacts */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Team</h2>
              <div className="grid md:grid-cols-3 gap-8">
                {/* Lead Partner */}
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Olawale Tunde Fasanya, Ph.D</CardTitle>
                    <CardDescription className="text-green-600 font-semibold">Lead Partner</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a
                      href="tel:+2348033313949"
                      className="flex items-center gap-3 hover:text-green-600 transition-colors"
                    >
                      <Phone className="h-5 w-5 text-green-600" />
                      <span>+234 803 331 3949</span>
                    </a>
                    <a
                      href="mailto:walefasanya@gmail.com"
                      className="flex items-center gap-3 hover:text-green-600 transition-colors"
                    >
                      <Mail className="h-5 w-5 text-green-600" />
                      <span className="break-all">walefasanya@gmail.com</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Partner */}
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Shehu Kadir</CardTitle>
                    <CardDescription className="text-green-600 font-semibold">Partner</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a
                      href="tel:+2348037911040"
                      className="flex items-center gap-3 hover:text-green-600 transition-colors"
                    >
                      <Phone className="h-5 w-5 text-green-600" />
                      <span>+234 803 791 1040</span>
                    </a>
                    <a
                      href="mailto:shehujazuli@yahoo.com"
                      className="flex items-center gap-3 hover:text-green-600 transition-colors"
                    >
                      <Mail className="h-5 w-5 text-green-600" />
                      <span className="break-all">shehujazuli@yahoo.com</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Secretary */}
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Salawu Ahmed</CardTitle>
                    <CardDescription className="text-green-600 font-semibold">Secretary</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a
                      href="tel:+2348146302064"
                      className="flex items-center gap-3 hover:text-green-600 transition-colors"
                    >
                      <Phone className="h-5 w-5 text-green-600" />
                      <span>+234 814 630 2064</span>
                    </a>
                    <a
                      href="mailto:mesalawu@gmail.com"
                      className="flex items-center gap-3 hover:text-green-600 transition-colors"
                    >
                      <Mail className="h-5 w-5 text-green-600" />
                      <span className="break-all">mesalawu@gmail.com</span>
                    </a>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Office Information */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Office</h2>
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-6 w-6 text-green-600" />
                    CETAPI Head Office
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-green-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Address:</p>
                      <p className="text-gray-700">Office No: 402 A, Nawa Complex</p>
                      <p className="text-gray-700">Kado/Gwarimpa, Abuja, Nigeria</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="font-semibold">Office Phone:</p>
                      <a href="tel:+2348033313949" className="text-gray-700 hover:text-green-600">
                        +234 803 331 3949
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Send Us a Message</h2>
              <p className="text-center text-gray-600 mb-8">
                Have questions or want to learn more? Fill out the form below and we'll get back to you soon.
              </p>
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium mb-2">
                        Name
                      </label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium mb-2">
                        Email
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="your.email@example.com"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium mb-2">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Tell us how we can help you..."
                        rows={6}
                      />
                    </div>
                    {submitStatus === "success" && (
                      <p className="text-green-600 text-sm">Thank you! Your message has been sent successfully.</p>
                    )}
                    {submitStatus === "error" && (
                      <p className="text-red-600 text-sm">
                        Sorry, there was an error sending your message. Please try again.
                      </p>
                    )}
                    <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isSubmitting}>
                      {isSubmitting ? "Sending..." : "Send Message"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
